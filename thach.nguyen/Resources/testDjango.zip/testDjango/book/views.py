from django.shortcuts import render

# Create your views here.


def index(request, page=1):
    return render(request, "book/index.html")


def add(request, page=1):
    return render(request, "book/index.html")